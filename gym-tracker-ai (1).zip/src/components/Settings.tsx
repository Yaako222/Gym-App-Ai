import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Settings as SettingsIcon, Moon, Sun, Globe, User, LogOut, Check, X } from 'lucide-react';
import { auth } from '../firebase';
import { logout } from '../firebase';
import { UserProfile } from '../types';
import { updateUserProfile, checkUsernameAvailability, getUserProfile } from '../utils/storage';

export default function Settings() {
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [isEditingUsername, setIsEditingUsername] = useState(false);
  const [newUsername, setNewUsername] = useState('');
  const [usernameError, setUsernameError] = useState('');
  const [isSavingUsername, setIsSavingUsername] = useState(false);
  
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  const [timezone, setTimezone] = useState<string>(Intl.DateTimeFormat().resolvedOptions().timeZone);
  
  const timezones = Intl.supportedValuesOf ? Intl.supportedValuesOf('timeZone') : [timezone];

  useEffect(() => {
    const loadProfile = async () => {
      if (auth.currentUser) {
        try {
          const userProfile = await getUserProfile(auth.currentUser.uid);
          if (userProfile) {
            setProfile(userProfile);
            setNewUsername(userProfile.username || '');
            if (userProfile.theme) setTheme(userProfile.theme);
            if (userProfile.timezone) setTimezone(userProfile.timezone);
          }
        } catch (error) {
          console.error("Error loading profile", error);
        }
      }
    };
    loadProfile();
  }, []);

  // Apply theme to document
  useEffect(() => {
    if (theme === 'light') {
      document.documentElement.classList.add('light-theme');
    } else {
      document.documentElement.classList.remove('light-theme');
    }
  }, [theme]);

  const handleSaveUsername = async () => {
    if (newUsername === profile?.username) {
      setIsEditingUsername(false);
      return;
    }

    if (newUsername.length < 3 || newUsername.length > 30) {
      setUsernameError('Benutzername muss zwischen 3 und 30 Zeichen lang sein.');
      return;
    }
    
    if (!/^[a-zA-Z0-9_]+$/.test(newUsername)) {
      setUsernameError('Nur Buchstaben, Zahlen und Unterstriche erlaubt.');
      return;
    }

    setIsSavingUsername(true);
    setUsernameError('');

    try {
      const isAvailable = await checkUsernameAvailability(newUsername);
      if (!isAvailable) {
        setUsernameError('Dieser Benutzername ist bereits vergeben.');
        setIsSavingUsername(false);
        return;
      }

      await updateUserProfile({ username: newUsername });
      setProfile(prev => prev ? { ...prev, username: newUsername } : null);
      setIsEditingUsername(false);
    } catch (err) {
      setUsernameError('Fehler beim Speichern.');
    } finally {
      setIsSavingUsername(false);
    }
  };

  const handleThemeChange = async (newTheme: 'dark' | 'light') => {
    setTheme(newTheme);
    await updateUserProfile({ theme: newTheme });
  };

  const handleTimezoneChange = async (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newTz = e.target.value;
    setTimezone(newTz);
    localStorage.setItem('gym_timezone', newTz);
    await updateUserProfile({ timezone: newTz });
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="flex items-center gap-3 mb-8">
        <div className="w-10 h-10 rounded-xl bg-[#1d7a82]/20 flex items-center justify-center border border-[#1d7a82]/30 glow-teal">
          <SettingsIcon className="w-5 h-5 text-[#1d7a82]" />
        </div>
        <h2 className="text-2xl font-bold text-white text-glow-teal">Einstellungen</h2>
      </div>

      <div className="bg-white/5 border border-white/10 rounded-2xl p-6 backdrop-blur-sm space-y-8">
        
        {/* Profile Section */}
        <section>
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2 border-b border-white/10 pb-2">
            <User className="w-5 h-5 text-[#FF0050]" />
            Profil
          </h3>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-400 mb-1">Benutzername</label>
              {isEditingUsername ? (
                <div className="space-y-2">
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={newUsername}
                      onChange={(e) => setNewUsername(e.target.value)}
                      className="flex-1 bg-black/20 border border-white/10 rounded-xl px-4 py-2 text-white focus:outline-none focus:border-[#1d7a82] transition-all"
                      placeholder="Neuer Benutzername"
                    />
                    <button
                      onClick={handleSaveUsername}
                      disabled={isSavingUsername}
                      className="bg-[#1d7a82] hover:bg-[#155e63] text-white p-2 rounded-xl transition-all disabled:opacity-50"
                    >
                      <Check className="w-5 h-5" />
                    </button>
                    <button
                      onClick={() => {
                        setIsEditingUsername(false);
                        setNewUsername(profile?.username || '');
                        setUsernameError('');
                      }}
                      className="bg-white/10 hover:bg-white/20 text-white p-2 rounded-xl transition-all"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                  {usernameError && <p className="text-[#FF0050] text-sm">{usernameError}</p>}
                  <p className="text-xs text-slate-500">Einmal vergebene Namen können von anderen nicht verwendet werden, solange du ihn hast.</p>
                </div>
              ) : (
                <div className="flex items-center justify-between bg-black/20 border border-white/5 rounded-xl p-3">
                  <span className="text-white font-medium">@{profile?.username || 'Laden...'}</span>
                  <button
                    onClick={() => setIsEditingUsername(true)}
                    className="text-sm text-[#1d7a82] hover:text-white transition-colors"
                  >
                    Bearbeiten
                  </button>
                </div>
              )}
            </div>
          </div>
        </section>

        {/* Preferences Section */}
        <section>
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2 border-b border-white/10 pb-2">
            <Globe className="w-5 h-5 text-[#1d7a82]" />
            Präferenzen
          </h3>
          
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-slate-400 mb-2">Erscheinungsbild</label>
              <div className="flex gap-2">
                <button
                  onClick={() => handleThemeChange('dark')}
                  className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl border transition-all ${theme === 'dark' ? 'bg-[#1d7a82]/20 border-[#1d7a82] text-white glow-teal' : 'bg-black/20 border-white/5 text-slate-400 hover:bg-white/5'}`}
                >
                  <Moon className="w-4 h-4" /> Dunkel
                </button>
                <button
                  onClick={() => handleThemeChange('light')}
                  className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl border transition-all ${theme === 'light' ? 'bg-white text-slate-900 border-white shadow-[0_0_15px_rgba(255,255,255,0.5)]' : 'bg-black/20 border-white/5 text-slate-400 hover:bg-white/5'}`}
                >
                  <Sun className="w-4 h-4" /> Hell
                </button>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-400 mb-1">Zeitzone</label>
              <select
                value={timezone}
                onChange={handleTimezoneChange}
                className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-[#1d7a82] transition-all appearance-none"
              >
                {timezones.map(tz => (
                  <option key={tz} value={tz} className="bg-[#1e293b]">{tz}</option>
                ))}
              </select>
              <p className="text-xs text-slate-500 mt-2">Wird für die korrekte Zuordnung deiner Workouts zum aktuellen Tag verwendet.</p>
            </div>
          </div>
        </section>

        {/* Account Section */}
        <section>
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2 border-b border-white/10 pb-2">
            <LogOut className="w-5 h-5 text-slate-400" />
            Konto
          </h3>
          
          <button
            onClick={logout}
            className="w-full flex items-center justify-center gap-2 bg-[#FF0050]/10 hover:bg-[#FF0050]/20 text-[#FF0050] border border-[#FF0050]/30 py-3 rounded-xl font-medium transition-all"
          >
            <LogOut className="w-5 h-5" />
            Abmelden
          </button>
        </section>

      </div>
    </div>
  );
}

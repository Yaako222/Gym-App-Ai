import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Plus, Dumbbell, Bookmark } from 'lucide-react';
import { DayOfWeek, MuscleCategory, ExercisePlan } from '../types';
import { addPlan } from '../utils/storage';

interface AddExerciseModalProps {
  isOpen: boolean;
  onClose: () => void;
  plans: ExercisePlan[];
}

const DAYS: DayOfWeek[] = ['Montag', 'Dienstag', 'Mittwoch', 'Donnerstag', 'Freitag', 'Samstag', 'Sonntag'];
const CATEGORIES: MuscleCategory[] = ['Arme', 'Beine', 'Brust', 'Rücken', 'Schultern', 'Bauch', 'Ganzkörper', 'Cardio', 'Andere'];

export default function AddExerciseModal({ isOpen, onClose, plans }: AddExerciseModalProps) {
  const [activeTab, setActiveTab] = useState<'saved' | 'new'>('saved');
  const [name, setName] = useState('');
  const [dayOfWeek, setDayOfWeek] = useState<DayOfWeek>('Montag');
  const [muscleGroup, setMuscleGroup] = useState<MuscleCategory>('Brust');

  // Get unique exercises grouped by muscle category
  const groupedSavedExercises = useMemo(() => {
    const unique = new Map<string, { name: string, muscleGroup: MuscleCategory }>();
    const sortedPlans = [...plans].sort((a, b) => new Date(b.dateAdded).getTime() - new Date(a.dateAdded).getTime());
    
    for (const plan of sortedPlans) {
      if (!unique.has(plan.name.toLowerCase())) {
        unique.set(plan.name.toLowerCase(), { name: plan.name, muscleGroup: plan.muscleGroup });
      }
    }

    const grouped: Record<string, { name: string, muscleGroup: MuscleCategory }[]> = {};
    Array.from(unique.values()).forEach(ex => {
      if (!grouped[ex.muscleGroup]) grouped[ex.muscleGroup] = [];
      grouped[ex.muscleGroup].push(ex);
    });

    return grouped;
  }, [plans]);

  const handleSelectSaved = (exercise: { name: string, muscleGroup: MuscleCategory }) => {
    setName(exercise.name);
    setMuscleGroup(exercise.muscleGroup);
    setActiveTab('new');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name) return;

    await addPlan({
      name,
      dayOfWeek,
      muscleGroup
    });

    setName('');
    setDayOfWeek('Montag');
    setMuscleGroup('Brust');
    setActiveTab('saved');
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-md bg-[#1e293b] border border-[#1d7a82]/50 shadow-[0_0_30px_rgba(29,122,130,0.2)] rounded-2xl z-50 overflow-hidden flex flex-col max-h-[85vh]"
          >
            <div className="flex justify-between items-center p-5 border-b border-white/10 shrink-0">
              <h2 className="text-xl font-semibold text-white text-glow-teal">Übung hinzufügen</h2>
              <button onClick={onClose} className="text-slate-400 hover:text-white hover:drop-shadow-[0_0_8px_rgba(255,255,255,0.8)] transition-all">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex border-b border-white/10 shrink-0">
              <button 
                onClick={() => setActiveTab('saved')} 
                className={`flex-1 py-3 text-sm font-medium transition-all flex items-center justify-center gap-2 ${activeTab === 'saved' ? 'text-[#1d7a82] border-b-2 border-[#1d7a82] bg-[#1d7a82]/10' : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'}`}
              >
                <Bookmark className="w-4 h-4" />
                Gespeichert
              </button>
              <button 
                onClick={() => setActiveTab('new')} 
                className={`flex-1 py-3 text-sm font-medium transition-all flex items-center justify-center gap-2 ${activeTab === 'new' ? 'text-[#1d7a82] border-b-2 border-[#1d7a82] bg-[#1d7a82]/10' : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'}`}
              >
                <Dumbbell className="w-4 h-4" />
                Neu erstellen
              </button>
            </div>
            
            <div className="overflow-y-auto p-5 custom-scrollbar">
              {activeTab === 'saved' ? (
                <div className="space-y-6">
                  {Object.keys(groupedSavedExercises).length === 0 ? (
                    <div className="text-center py-8">
                      <p className="text-slate-400 mb-4">Du hast noch keine Übungen gespeichert.</p>
                      <button 
                        onClick={() => setActiveTab('new')}
                        className="bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-xl text-sm transition-all"
                      >
                        Erste Übung erstellen
                      </button>
                    </div>
                  ) : (
                    Object.entries(groupedSavedExercises).map(([muscleGroup, exercises]) => (
                      <div key={muscleGroup} className="space-y-3">
                        <h3 className="text-sm font-semibold text-white flex items-center gap-2 border-b border-white/10 pb-1">
                          <span className="w-2 h-4 bg-[#FF0050] rounded-full glow-pink"></span>
                          {muscleGroup}
                        </h3>
                        <div className="grid grid-cols-1 gap-2">
                          {exercises.map((ex, idx) => (
                            <button
                              key={idx}
                              onClick={() => handleSelectSaved(ex)}
                              className="text-left bg-white/5 border border-white/10 hover:border-[#1d7a82]/50 hover:bg-[#1d7a82]/10 text-slate-200 p-3 rounded-xl transition-all flex justify-between items-center group"
                            >
                              <span>{ex.name}</span>
                              <Plus className="w-4 h-4 text-slate-500 group-hover:text-[#1d7a82]" />
                            </button>
                          ))}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">Übungsname</label>
                    <input
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="z.B. Bankdrücken"
                      className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-2.5 text-white focus:outline-none focus:border-glow-teal transition-all"
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-slate-300 mb-1">Muskelgruppe</label>
                      <select
                        value={muscleGroup}
                        onChange={(e) => setMuscleGroup(e.target.value as MuscleCategory)}
                        className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-2.5 text-white focus:outline-none focus:border-glow-teal transition-all appearance-none"
                      >
                        {CATEGORIES.map(cat => (
                          <option key={cat} value={cat} className="bg-[#1e293b]">{cat}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-300 mb-1">Wochentag</label>
                      <select
                        value={dayOfWeek}
                        onChange={(e) => setDayOfWeek(e.target.value as DayOfWeek)}
                        className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-2.5 text-white focus:outline-none focus:border-glow-teal transition-all appearance-none"
                      >
                        {DAYS.map(day => (
                          <option key={day} value={day} className="bg-[#1e293b]">{day}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="pt-4">
                    <button
                      type="submit"
                      className="w-full bg-[#FF0050] hover:bg-[#e60048] text-white py-3 rounded-xl font-medium transition-all glow-pink active:scale-95 border border-[#FF0050]"
                    >
                      Zum Plan hinzufügen
                    </button>
                  </div>
                </form>
              )}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
